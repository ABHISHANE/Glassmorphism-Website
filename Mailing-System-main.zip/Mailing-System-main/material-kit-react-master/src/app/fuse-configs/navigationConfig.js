const navigationConfig = [

            
           
            {
                'id': 'academic-component', 
                'title':'Academics', 
                'type' : 'item',
                'icon' : 'whatshot',
                'url'  : '/academy'
            }
            
];

export default navigationConfig;
