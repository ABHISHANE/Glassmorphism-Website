import React from 'react';
import {Hidden, Icon, IconButton, Input, Paper} from '@material-ui/core';
import {ThemeProvider} from '@material-ui/styles';

function MailAppHeader(props)
{
   
    return (
        <div>
        'hello'
        </div>        
    );
}

export default MailAppHeader;
